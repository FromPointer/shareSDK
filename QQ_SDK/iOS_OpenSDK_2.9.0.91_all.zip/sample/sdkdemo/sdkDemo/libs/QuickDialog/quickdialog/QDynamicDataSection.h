#import <Foundation/Foundation.h>

#import "QSection.h"
@interface QDynamicDataSection : QSection {



}
@property(nonatomic, strong) NSString *emptyMessage;


@end