//
//  QPickerTabDelimitedStringParser.h
//  QuickDialog
//
//  Created by HiveHicks on 05.04.12.
//

#import <Foundation/Foundation.h>
#import "QPickerValueParser.h"

@interface QPickerTabDelimitedStringParser : NSObject <QPickerValueParser>

@end
