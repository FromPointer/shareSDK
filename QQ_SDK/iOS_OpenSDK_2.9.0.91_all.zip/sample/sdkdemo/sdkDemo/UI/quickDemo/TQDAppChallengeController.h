//
//  TQDAppChallengeController.h
//  tencentOAuthDemo
//
//  Created by 易壬俊 on 13-6-19.
//
//

#import "TQDQuickDialogController.h"

@interface TQDAppChallengeController : TQDQuickDialogController

@end
