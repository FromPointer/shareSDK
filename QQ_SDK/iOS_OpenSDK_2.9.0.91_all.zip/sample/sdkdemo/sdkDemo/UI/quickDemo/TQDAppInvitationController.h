//
//  TQDAppInvitationController.h
//  tencentOAuthDemo
//
//  Created by 易壬俊 on 13-6-3.
//
//

#import "TQDQuickDialogController.h"

@interface TQDAppInvitationController : TQDQuickDialogController

@end
