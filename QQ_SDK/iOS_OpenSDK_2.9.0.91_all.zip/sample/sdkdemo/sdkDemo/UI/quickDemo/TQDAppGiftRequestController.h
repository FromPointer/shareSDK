//
//  TQDAppGiftRequestController.h
//  tencentOAuthDemo
//
//  Created by 易壬俊 on 13-6-24.
//
//

#import "TQDQuickDialogController.h"

@interface TQDAppGiftRequestController : TQDQuickDialogController

@end
