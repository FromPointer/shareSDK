//
//  TextAlertView.h
//  sdkDemo
//
//  Created by xiaolongzhang on 13-4-1.
//  Copyright (c) 2013年 xiaolongzhang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextAlertView : UIAlertView

@end
